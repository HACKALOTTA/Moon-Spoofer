#pragma

class c_globals
{
public:
	bool active = true;
} globals;